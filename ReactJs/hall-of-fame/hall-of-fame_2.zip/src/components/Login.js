import Container from '@mui/material/Container';
import Button from '@mui/material/Button';
import TextField from '@mui/material/TextField';
import Grid from '@mui/material/Grid';
import Typography from '@mui/material/Typography';
import Divider from '@mui/material/Divider';
import Paper from '@mui/material/Paper';
import Box from '@mui/material/Box';
import { AuthContext } from "../App";
import React from 'react';
import { useState } from 'react';

export default function Login () {

 const { dispatch } = React.useContext(AuthContext);

const [email, setEmail] = useState(null);
  const [password, setPassword] = useState(null);

const onLogin = () => {

  dispatch({
            type: "LOGIN",
            payload: {
        isAuthenticated: false,
        firstName: 'Sreehari'
      }
        })

}


const handleEmailChange = (event) => {
    setEmail(event.target.value);
  };

const handlePasswordChange = (event) => {
    setPassword(event.target.value);
  };


  return (
<>
<TextField
          id="txtLinkedIn"
          label="linkedIn"
          variant="outlined"
          onChange={handleEmailChange}
          value={(email && email) || ''}
        />
<TextField
          id="txtEmail"
          label="Email"
          variant="outlined"
          onChange={handlePasswordChange}
          value={(password && password) || ''}
/>
<Button disabled={!(email && password)}  variant="contained" onClick={onLogin}>Login</Button>
</>
  );
}