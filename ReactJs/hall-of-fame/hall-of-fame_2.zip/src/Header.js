import { BrowserRouter as Router, Route, Switch } from 'react-router-dom'
import { AuthContext } from "../src/App";
import React from "react";

import AppBar from '@mui/material/AppBar';
import Toolbar from '@mui/material/Toolbar';
import { Link} from 'react-router-dom'
import Grid from '@mui/material/Grid';

export default function Header () {
const { state, dispatch } = React.useContext(AuthContext);
  return (
<AppBar sx={{background: 'black'}} position="static">
        <Toolbar>
          <Grid container>
          <Grid item xs={10} />
          <Grid item xs={1} >
          <Link to='/' style={{color: 'white'}}>Add Task</Link>
          </Grid>
          <Grid item xs={1} >
           {state.isAuthenticated && (
          <h1>Hi {state.firstName} (LOGOUT)</h1>
        )}
          </Grid>
          </Grid>
        </Toolbar>
      </AppBar>
  );
}